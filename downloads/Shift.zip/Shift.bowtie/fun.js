oldPlayState = 0;
function $(el) { return document.getElementById(el); }

function artworkUpdate(artURL)
{
	$("artwork").style.webkitMaskPositionY = "160px";
	
	if (artURL == "")
		// use "no art" image
		$('background').src = "images/noart.png";
	else
		// use artURL
		$('background').src = artURL;
	
	$("artwork").style.webkitMaskPositionY = "480px";
	
	setTimeout("animationDone();", 1000);
}

function animationDone(){
	$("artwork").src = $("background").src;
	$("artwork").style.webkitMaskPositionY = "160px";
}

function playPause()
{
	Player.playPause();
	playerUpdate();
}

function playerUpdate()
{
	var pState = Player.playState();
	if (pState != oldPlayState)
	{
		if (pState == 0 || pState == 2)
			$('playLink').innerHTML = '<img src="images/play.png">';
		else
			$('playLink').innerHTML = '<img src="images/pause.png">';
		
		oldPlayState = pState;
	}
}

function hover(a) {
		var isEnter = a.property("enter");
		
		if(isEnter) {
			$('controls').style.opacity = "1";
		} else {
			$('controls').style.opacity = "0";
		}
	}

function init() {
	Bowtie.addMouseTrackingForElement($('artwork'), 'hover');
}

window.addEventListener("load", init, false);